public enum EnemyType
{
    Normal,
    Heavy,
    Speedy,
    Ranger,
}