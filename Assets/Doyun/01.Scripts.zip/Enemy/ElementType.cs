public enum ElementType
{
    Fire,
    Water,
    Earth,
    Air
}